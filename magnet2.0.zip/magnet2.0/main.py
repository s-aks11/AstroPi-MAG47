import os
from pathlib import Path
from picamera import PiCamera
from time import sleep
from PIL import Image
from pycoral.adapters import common
from pycoral.adapters import classify
from pycoral.utils.edgetpu import make_interpreter
from pycoral.utils.dataset import read_label_file
import cv2
import numpy as np
from fastiecm import fastiecm
from pycoral.utils.dataset import read_label_file
from logzero import logger, logfile
from orbit import ISS
from datetime import datetime, timedelta


"""Declaring variables and assigning base values"""
start_time = datetime.now()
now_time = datetime.now()
counter = 1
my_dir_path = Path(os.getcwd())
my_dir = str(Path(os.getcwd()))
model_file = my_dir_path/'model(F).tflite'
label_file = my_dir_path/'day-vs-night.txt'
image_dir = my_dir_path/'images/original'
image_con_dir = my_dir_path/'images/contrasted'
image_ncon_dir = my_dir_path/'images/ndvi_contrasted'
image_comap_dir = my_dir_path/'images/color_mapped'
camera = PiCamera()
camera.resolution = (2592,1944)
logfile(my_dir_path/"events.log")

def chkncreatefolder(mypath):
    """ Checks if the directories are created and, if not, then creates them """
    if not os.path.exists(mypath):
        os.makedirs(mypath)
        logger.info('Directory created :' + mypath)

def picapture(i):
    """ Capturing pictures (with Lat/Lon values) and saving them"""
    location = ISS.coordinates()
    camera.capture(str(image_dir) + '/image%s.jpg' % i)
    sleep(5)
    logger.info('Captured ' + str(image_dir) + '/image' + str(i) + '.jpg')
    logger.info('LAT:' + str(location.latitude.degrees))
    logger.info('LON:' + str(location.longitude.degrees))
    """Calling the function classifier"""
    classifier(str(image_dir) + '/image' + str(i) + '.jpg')

def classifier(image_file):
    """Uses a model to sort images into day type and non-day type"""
    interpreter = make_interpreter(f"{model_file}")
    interpreter.allocate_tensors()

    size = common.input_size(interpreter)
    image = Image.open(image_file).convert('RGB').resize(size, Image.ANTIALIAS)

    common.set_input(interpreter, image)
    interpreter.invoke()
    classes = classify.get_classes(interpreter, top_k=1)
    
    labels = read_label_file(label_file)
    for c in classes:
        imagetype = f'{labels.get(c.id, c.id)}'
    """
    If the image is classified as day type, the program calls the function ndvinum
    If the image is classified as non-day type, the program deletes it immediately
    """
    if imagetype != 'day':
        logger.info('Classified ' + image_file + ' as non-day type')
        os.remove(image_file)
        logger.info("Deleted image: " + image_file)
    if imagetype == 'day':
        logger.info('Classified ' + image_file + ' as day type')
        ndvinum(image_file)
        logger.info('NDVI color mapping for ' + image_file + ' complete')

def ndvinum(image_file):
    """Scans through each picture in the 'original' images file and contrasts/colour maps them in accordance to NDVI values
    Returns 3 new images and saves them to their respective folders"""
    if os.path.isfile(image_file):
        original = cv2.imread(str(image_file))
        def display(image, image_name):
            image = np.array(image, dtype=float)/float(255)
            shape = image.shape
            height = int(shape[0] / 2)
            width = int(shape[1] / 2)
            image = cv2.resize(image, (width, height))

        def contrast_stretch(im):
            in_min = np.percentile(im, 5)
            in_max = np.percentile(im, 95)
            
            out_min = 0.0
            out_max = 255.0

            out = im - in_min
            out *= ((out_min - out_max) / (in_min - in_max))
            out += in_min

            return out

        def calc_ndvi(image):
            b, g, r = cv2.split(image)
            bottom = (r.astype(float) + b.astype(float))
            bottom[bottom==0] = 0.01
            ndvi = (b.astype(float) - r) / bottom
            return ndvi

        display(original, 'original_name')
        contrasted = contrast_stretch(original)
        display(contrasted, 'Contrasted original')
        cv2.imwrite(str(image_con_dir) + '/' + os.path.basename(image_file).split('/')[-1] + '.contrasted.png', contrasted)
        ndvi = calc_ndvi(contrasted)
        
        def contrast_stretch(im):
            in_min = np.percentile(im, 5)
            in_max = np.percentile(im, 95)
            
            out_min = 0.0
            out_max = 255.0

            out = im - in_min
            out *= ((out_min - out_max) / (in_min - in_max))
            out += in_min

            return out

        def calc_ndvi(image):
            b, g, r = cv2.split(image)
            bottom = (r.astype(float) + b.astype(float))
            bottom[bottom==0] = 0.01
        display(ndvi, 'NDVI')
        ndvi_contrasted = contrast_stretch(ndvi)
        display(ndvi_contrasted, 'NDVI Contrasted')
        cv2.imwrite(str(image_ncon_dir) + '/' + os.path.basename(image_file).split('/')[-1] + '.ndvi_contrasted.png', ndvi_contrasted)
        color_mapped_prep = ndvi_contrasted.astype(np.uint8)
        color_mapped_image = cv2.applyColorMap(color_mapped_prep, fastiecm)
        display(color_mapped_image, 'Color mapped')
        cv2.imwrite(str(image_comap_dir) + '/' + os.path.basename(image_file).split('/')[-1] +  '.color_mapped_image.png', color_mapped_image)

"""Creates folders when program is started by calling the previous function"""
logger.info('MAGNET - Program Started')
logger.info('Current working directory :' + my_dir)
chkncreatefolder(str(image_dir))
chkncreatefolder(str(image_con_dir))
chkncreatefolder(str(image_ncon_dir))
chkncreatefolder(str(image_comap_dir))

# Run a loop for approx 3 hours
""" Starts program (on loop) by calling the function picapture and is set to run for for 178 minutes
If any errors occur, a message will be returned in the logfile. """
while (now_time < start_time + timedelta(minutes=178)):
    try:
        picapture(counter)
        counter += 1
        now_time = datetime.now()
    except Exception as ex:
        logger.info('Error with image counter ' + str(counter))
        if hasattr(ex, 'message'):
            logger.info(ex.message)
        else:
            logger.info(ex)
camera.close()
logger.info('MAGNET - Program Successfully Completed in ' + str(now_time - start_time))
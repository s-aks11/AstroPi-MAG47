AstroPi Mission Space Lab 
Team: Magnet 2.0

*************************************************

Table of Contents

1. Project Description
2. Files required
3. Internal workings
4. Testing
5. Credits 

*************************************************

1. Project Description

This program is designed to capture pictures of the Earth while the ISS is in orbit and alter them to produce NDVI color mapped images so they can later be used to map the Earth’s overall ‘green space’ and calculate different usages of land (i.e. agriculture, forestry, etc). 

*************************************************

2. Files Required

This program is able to run offline without any interactions/input. The files it requires to successfully run include: 
- main.py
- model(F).tflite
- fastiecm.py
- day-vs-night.txt

*************************************************

3. Internal Workings

This program utilizes multiple procedures/functions to successfully run. These are listed below (in order) as well any other information relevant to the code. 

a. All variables are declared and assigned base values 

b. Function: chkncreatefolder 
	- Parameter Needed: Folder Name
	- Checks if the specified folder exists in the current working directory, if not, create the same.

c. Procedure: picapture
	- Parameter Needed: N/A
	- Captures pictures using PiCamera and saves them to their respective folder (images/original). 
	- Logs events along with longitude and latitude values using the ISS module.
	- Calls another function labeled “classifier” along with the parameter value - Image Name.

d. Function: classifier
	- Parameter Needed: Image Name
	- Utilizes a previously trained model and the day-vs-night text file to label and sort images into 2 categories (day type or non-day type). 
	- If the image file is classified as non-day type, the program deletes the file (as it is not needed and will only take up space). 
	- If the image file is classified as day type, then the program calls the function labeled "ndvinum" along with the parameter value - Image Name. 

e. Function: ndvinum
	- Parameter Needed: Image Name
	- Scans each image file and contrasts/color maps them by using the file fastiecm.py which supplies NDVI values.
	- When complete, it returns 3 new image files and saves them to their respective folders(contrasted, ndvi_contrasted, or colour_mapped).

f. The program starts by calling the function “chkncreatefolder”. Then, it is put in a while-try loop and is set to run for approximately 180 minutes(total = 178 minutes). This program then calls the procedure “picapture” to begin. If any errors occur, a message will be returned in the log file. The camera is closed after the program is complete. 

*************************************************

4. Testing

To ensure that our program will be successful, we completed multiple tests throughout our design. Some of the scenarios executed include: 

- Performed unit testing by testing individual procedure(s).
- Ran the program end-to-end for a complete ‘day’ scenario.
- Ran the program end-to-end for a complete ‘night’  scenario.
- Ran the program end-to-end  for a combination of night and day scenario.
- Ensured the machine model used is able to correctly sort pictures into non-day type and day type. 
- Ensured that the usage of data is under 3GB.
- Ensured that the program finished within 3 hours.
- Ensured that there is no user input required to execute the program as well as throughout the duration of the program.
- Ensured all given criteria is met.

*************************************************

5. Credits
Teacher/Mentor: Mr. Christopher McFadden
Group Members: Akshita Sharma, Jessica Anirisaihan 
School: O’Neil CVI, Oshawa, ON, Canada

*************************************************
